(function() {
    if (typeof aerosearch_data === 'undefined') return;

    const ENDPOINT = aerosearch_data.endpoint;
    const origin = new URL(window.location.href).origin;
    const dropdown = document.getElementById('aerosearch-sync-interval-dropdown');
    const controls = document.getElementById('aerosearch-dashboard-controls');
    const externalMessage = document.getElementById('aerosearch-external-sync-message');
    const projectNotAssociatedMessage = document.getElementById('aerosearch-project-not-associated');
    const projectNameSpan = document.getElementById('aerosearch-project-name');
    const lastSyncedAtSpan = document.getElementById('aerosearch-last-synced-at');
    const syncIntervalSection = document.getElementById('aerosearch-sync-interval-section');

    // Change Key Button
    const changeKeyButton = document.getElementById('aerosearch-change-key-button');
    if (changeKeyButton) {
        changeKeyButton.addEventListener('click', function() {
            if (controls) controls.style.display = 'none';
            if (projectNotAssociatedMessage) projectNotAssociatedMessage.style.display = 'block';
            const keyInput = document.getElementById('aerosearch-project-key');
            if (keyInput) keyInput.value = '';
        });
    }

    const formatDateTime = (isoString) => {
        if (!isoString) return aerosearch_data.i18n.never;
        try {
            const date = new Date(isoString);
            return new Intl.DateTimeFormat(navigator.language, {
                dateStyle: 'medium',
                timeStyle: 'short'
            }).format(date);
        } catch (e) {
            return isoString;
        }
    };

    // Fetch and populate sync intervals
    if (controls) {
        fetch(ENDPOINT + "/api/store/info", {
            headers: {
                'x-site-domain': origin,
            }
        })
        .then(response => {
            if (response.status === 422) {
                if (projectNotAssociatedMessage) projectNotAssociatedMessage.style.display = 'block';
                controls.style.display = 'none';
                throw new Error('Project not associated');
            }
            return response.json();
        })
        .then(data => {
            if (data.isExternal) {
                if (externalMessage) externalMessage.style.display = 'block';
                controls.style.display = 'none';
                return;
            }

            controls.style.display = 'block';
            if (projectNameSpan) projectNameSpan.textContent = data.name || aerosearch_data.i18n.na;
            if (lastSyncedAtSpan) lastSyncedAtSpan.textContent = formatDateTime(data.lastSyncedAt);

            if (data.isSyncIntervalDisabled && syncIntervalSection) {
                syncIntervalSection.style.display = 'none';
            }

            if (data.intervalTags && Array.isArray(data.intervalTags) && dropdown) {
                dropdown.innerHTML = '';
                data.intervalTags.forEach(tag => {
                    const option = document.createElement('option');
                    option.value = tag;
                    option.textContent = tag;
                    if (data.interval && data.interval.tag === tag) {
                        option.selected = true;
                    }
                    dropdown.appendChild(option);
                });
            }
        })
        .catch(error => console.error('Error fetching store info:', error));
    }

    // Trigger Products Sync
    const syncButton = document.getElementById('aerosearch-sync-products-button');
    if (syncButton) {
        syncButton.addEventListener('click', function() {
            const button = this;
            const status = document.getElementById('aerosearch-sync-status');
            
            button.disabled = true;
            if (status) {
                status.textContent = aerosearch_data.i18n.syncing;
                status.style.color = 'inherit';
            }

            fetch(ENDPOINT + "/api/store/sync", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-site-domain': origin,
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const contentType = response.headers.get("content-type");
                if (contentType && contentType.indexOf("application/json") !== -1) {
                    return response.json();
                } else {
                    return response.text();
                }
            })
            .then(data => {
                if (status) {
                    status.textContent = aerosearch_data.i18n.syncSuccess;
                    status.style.color = 'green';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                if (status) {
                    status.textContent = aerosearch_data.i18n.syncFailed;
                    status.style.color = 'red';
                }
            })
            .finally(() => {
                button.disabled = false;
            });
        });
    }

    // Update Sync Interval
    const updateIntervalButton = document.getElementById('aerosearch-update-sync-interval-button');
    if (updateIntervalButton) {
        updateIntervalButton.addEventListener('click', function() {
            const button = this;
            const status = document.getElementById('aerosearch-update-interval-status');
            const intervalTag = dropdown ? dropdown.value : '';

            button.disabled = true;
            if (status) {
                status.textContent = aerosearch_data.i18n.updating;
                status.style.color = 'inherit';
            }

            fetch(ENDPOINT + "/api/store/info", {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'x-site-domain': origin,
                },
                body: JSON.stringify({ intervalTag: intervalTag })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                if (status) {
                    status.textContent = aerosearch_data.i18n.updateSuccess;
                    status.style.color = 'green';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                if (status) {
                    status.textContent = aerosearch_data.i18n.updateFailed;
                    status.style.color = 'red';
                }
            })
            .finally(() => {
                button.disabled = false;
            });
        });
    }

    // Confirm Project Key
    const confirmKeyButton = document.getElementById('aerosearch-confirm-key-button');
    if (confirmKeyButton) {
        confirmKeyButton.addEventListener('click', function() {
            const button = this;
            const status = document.getElementById('aerosearch-confirm-key-status');
            const keyInput = document.getElementById('aerosearch-project-key');
            const key = keyInput ? keyInput.value.trim() : '';
            
            if (!key) {
                alert(aerosearch_data.i18n.enterKey);
                return;
            }

            button.disabled = true;
            if (status) {
                status.textContent = aerosearch_data.i18n.submitting;
                status.style.color = 'inherit';
            }

            fetch(ENDPOINT + "/api/project/" + encodeURIComponent(key) + "/domain", {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'x-site-domain': origin,
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                window.location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
                if (status) {
                    status.textContent = aerosearch_data.i18n.updateFailed;
                    status.style.color = 'red';
                }
            })
            .finally(() => {
                button.disabled = false;
            });
        });
    }
})();
