<?php
/**
 * Plugin Name: Aerosearch
 * Plugin URI:  https://aerosearch.cloud
 * Description: All you need with a WooCommerce search extension.
 * Version:     1.0.0
 * Author:      Misiki Tech
 * Author URI:  https://github.com/misiki-in
 * License:     Apache-2.0
 * License URI: https://www.apache.org/licenses/LICENSE-2.0.txt
 * Text Domain: woocommerce-search
 * Domain Path: /languages
 *
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

const WC_SEARCH_ENDPOINT = 'https://api.wooquery.com';

/**
 * Activation hook
 */
function wc_advanced_search_activate() {
	$domain = home_url();
	error_log( 'WC Advanced Search activating for domain: ' . $domain );
	$response = wp_remote_post( WC_SEARCH_ENDPOINT . "/api/store/activate", array(
		'headers' => array(
			'x-site-domain' => $domain,
		),
	) );

	if ( is_wp_error( $response ) ) {
		error_log( 'WC Advanced Search activation request failed: ' . $response->get_error_message() );
	} else {
		error_log( 'WC Advanced Search activation request sent. Response code: ' . wp_remote_retrieve_response_code( $response ) );
	}
}

/**
 * Deactivation hook
 */
function wc_advanced_search_deactivate() {
	$domain = home_url();
	error_log( 'WC Advanced Search deactivating for domain: ' . $domain );
	$response = wp_remote_request( WC_SEARCH_ENDPOINT . "/api/store/deactivate", array(
		'method'  => 'DELETE',
		'headers' => array(
			'x-site-domain' => $domain,
		),
	) );

	if ( is_wp_error( $response ) ) {
		error_log( 'WC Advanced Search deactivation request failed: ' . $response->get_error_message() );
	} else {
		error_log( 'WC Advanced Search deactivation request sent. Response code: ' . wp_remote_retrieve_response_code( $response ) );
	}
}

register_activation_hook( __FILE__, 'wc_advanced_search_activate' );
register_deactivation_hook( __FILE__, 'wc_advanced_search_deactivate' );

/**
 * Check if WooCommerce is active
 **/
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}

/**
 * Main WooCommerce Search Class
 */
class WC_Advanced_Search {

	/**
	 * Instance of this class.
	 *
	 * @var WC_Advanced_Search
	 */
	private static $_instance = null;

	/**
	 * Get the instance of this class.
	 *
	 * @return WC_Advanced_Search
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Prevent cloning the instance.
	 */
	private function __clone() {}

	/**
	 * Prevent unserializing the instance.
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'woocommerce-search' ), '1.0.0' );
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'wp_footer', array( $this, 'enqueue_storefront_scripts' ) );
	}

	/**
	 * Enqueue Storefront Scripts
	 *
	 * Outputs the script tag directly in the footer with defer attribute.
	 * Only runs on the storefront (is_admin() check).
	 */
	public function enqueue_storefront_scripts() {
		if ( is_admin() ) {
			return;
		}

		$script_url = plugins_url( 'assets/js/main.js', __FILE__ );
		?>
		<script type="text/javascript" src="<?php echo esc_url( $script_url ); ?>" defer></script>
		<?php
	}

	/**
	 * Add Admin Menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'AeroSearch', 'woocommerce-search' ),
			__( 'AeroSearch', 'woocommerce-search' ),
			'manage_options',
			'wc-advanced-search',
			array( $this, 'render_dashboard' ),
			'dashicons-search',
			56
		);
	}

	/**
	 * Render Dashboard Page
	 */
	public function render_dashboard() {
		?>
		<div class="wrap">
			<h1><?php _e( 'AeroSearch Dashboard', 'woocommerce-search' ); ?></h1>
			<p><?php _e( 'Manage your search settings and sync products.', 'woocommerce-search' ); ?></p>
			<p style="background-color: yellow; padding: 10px; font-weight: bold;"><?php _e( 'This plugin requires a ecommerce theme with a search bar.', 'woocommerce-search' ); ?></p>
			
			<hr />

			<div id="external-sync-message" style="display: none; margin-top: 20px; padding: 10px; background: #fff; border-left: 4px solid #ffba00; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
				<strong><?php _e( 'Sync is managed externally', 'woocommerce-search' ); ?></strong>
			</div>

			<div id="project-not-associated" style="display: none; margin-top: 20px; padding: 20px; background: #fff; border-left: 4px solid #dc3232; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
				<!-- <h3><?php _e( 'Currently not associated with any project', 'woocommerce-search' ); ?></h3> -->
				<div style="margin-top: 15px;">
					<label for="project-key" style="display: block; margin-bottom: 5px;"><strong><?php _e( 'Key', 'woocommerce-search' ); ?></strong></label>
					<p style="margin-top: 15px;">
						<?php _e( 'Get the key', 'woocommerce-search' ); ?> <a href="https://aerosearch.cloud/dash" target="_blank"> here. </a>
					</p>
					<input type="text" id="project-key" style="width: 300px; margin-bottom: 10px;" />
					<br />
					<button id="confirm-key-button" class="button button-primary">
						<?php _e( 'Confirm Key', 'woocommerce-search' ); ?>
					</button>
					<span id="confirm-key-status" style="margin-left: 10px;"></span>
					<p style="margin-top: 15px;">
						<?php _e( 'Get a step by step interactive guide on how to setup', 'woocommerce-search' ); ?> <a href="https://aerosearch.cloud/guide" target="_blank"> here. </a>
					</p>
				</div>
			</div>

			<div id="dashboard-controls" style="display: none;">
				<div class="project-settings-section" style="margin-top: 20px; padding: 20px; background: #fff; border-left: 4px solid #0073aa; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
					<h3 style="margin-top: 0;"><?php _e( 'Project settings', 'woocommerce-search' ); ?></h3>
					<p><strong><?php _e( 'Project Name', 'woocommerce-search' ); ?>:</strong> <span id="project-name"></span></p>
					<button id="change-key-button" class="button button-secondary">
						<?php _e( 'Change Key', 'woocommerce-search' ); ?>
					</button>
				</div>

				<div class="sync-settings-section" style="margin-top: 20px; padding: 20px; background: #fff; border-left: 4px solid #46b450; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
					<h3 style="margin-top: 0;"><?php _e( 'Sync Settings', 'woocommerce-search' ); ?></h3>
					<p><strong><?php _e( 'Last Synced At', 'woocommerce-search' ); ?>:</strong> <span id="last-synced-at"></span></p>

					<div id="sync-interval-section" class="sync-interval-section" style="margin-top: 20px;">
						<label for="sync-interval-dropdown"><strong><?php _e( 'Sync interval', 'woocommerce-search' ); ?>:</strong> </label>
						<select id="sync-interval-dropdown" style="min-width: 150px;"></select>
						<button id="update-sync-interval-button" class="button button-secondary">
							<?php _e( 'Update Sync Interval', 'woocommerce-search' ); ?>
						</button>
						<span id="update-interval-status" style="margin-left: 10px;"></span>
					</div>

					<div class="sync-section" style="margin-top: 20px; border-top: 1px solid #ddd; padding-top: 20px;">
						<button id="sync-products-button" class="button button-primary">
							<?php _e( 'Trigger Products Sync', 'woocommerce-search' ); ?>
						</button>
						<span id="sync-status" style="margin-left: 10px;"></span>
					</div>
				</div>
			</div>

			<script type="text/javascript">
				(function() {
					const ENDPOINT = "<?php echo WC_SEARCH_ENDPOINT; ?>";
					const origin = new URL(window.location.href).origin;
					const dropdown = document.getElementById('sync-interval-dropdown');
					const controls = document.getElementById('dashboard-controls');
					const externalMessage = document.getElementById('external-sync-message');
					const projectNotAssociatedMessage = document.getElementById('project-not-associated');
					const projectNameSpan = document.getElementById('project-name');
					const lastSyncedAtSpan = document.getElementById('last-synced-at');
					const syncIntervalSection = document.getElementById('sync-interval-section');

					// Change Key Button
					document.getElementById('change-key-button').addEventListener('click', function() {
						controls.style.display = 'none';
						projectNotAssociatedMessage.style.display = 'block';
						document.getElementById('project-key').value = '';
					});

					const formatDateTime = (isoString) => {
						if (!isoString) return '<?php _e( 'Never', 'woocommerce-search' ); ?>';
						try {
							const date = new Date(isoString);
							return new Intl.DateTimeFormat(navigator.language, {
								dateStyle: 'medium',
								timeStyle: 'short'
							}).format(date);
						} catch (e) {
							return isoString;
						}
					};

					// Fetch and populate sync intervals
					fetch(ENDPOINT + "/api/store/info", {
						headers: {
							'x-site-domain': origin,
						}
					})
					.then(response => {
						if (response.status === 422) {
							projectNotAssociatedMessage.style.display = 'block';
							controls.style.display = 'none';
							throw new Error('Project not associated');
						}
						return response.json();
					})
					.then(data => {
						if (data.isExternal) {
							externalMessage.style.display = 'block';
							controls.style.display = 'none';
							return;
						}

						controls.style.display = 'block';
						projectNameSpan.textContent = data.name || '<?php _e( 'N/A', 'woocommerce-search' ); ?>';
						lastSyncedAtSpan.textContent = formatDateTime(data.lastSyncedAt);

						if (data.isSyncIntervalDisabled) {
							syncIntervalSection.style.display = 'none';
						}

						if (data.intervalTags && Array.isArray(data.intervalTags)) {
							data.intervalTags.forEach(tag => {
								const option = document.createElement('option');
								option.value = tag;
								option.textContent = tag;
								if (data.interval && data.interval.tag === tag) {
									option.selected = true;
								}
								dropdown.appendChild(option);
							});
						}
					})
					.catch(error => console.error('Error fetching store info:', error));

					// Trigger Products Sync
					document.getElementById('sync-products-button').addEventListener('click', function() {
						const button = this;
						const status = document.getElementById('sync-status');
						
						button.disabled = true;
						status.textContent = '<?php _e( 'Syncing...', 'woocommerce-search' ); ?>';
						status.style.color = 'inherit';

						fetch(ENDPOINT + "/api/store/sync", {
							method: 'POST',
							headers: {
								'Content-Type': 'application/json',
								'x-site-domain': origin,
							}
						})
						.then(response => {
							if (!response.ok) {
								throw new Error('Network response was not ok');
							}
							const contentType = response.headers.get("content-type");
							if (contentType && contentType.indexOf("application/json") !== -1) {
								return response.json();
							} else {
								return response.text();
							}
						})
						.then(data => {
							status.textContent = '<?php _e( 'Sync successful!', 'woocommerce-search' ); ?>';
							status.style.color = 'green';
						})
						.catch(error => {
							console.error('Error:', error);
							status.textContent = '<?php _e( 'Sync failed. Please try again.', 'woocommerce-search' ); ?>';
							status.style.color = 'red';
						})
						.finally(() => {
							button.disabled = false;
						});
					});

					// Update Sync Interval
					document.getElementById('update-sync-interval-button').addEventListener('click', function() {
						const button = this;
						const status = document.getElementById('update-interval-status');
						const intervalTag = dropdown.value;

						button.disabled = true;
						status.textContent = '<?php _e( 'Updating...', 'woocommerce-search' ); ?>';
						status.style.color = 'inherit';

						fetch(ENDPOINT + "/api/store/info", {
							method: 'PUT',
							headers: {
								'Content-Type': 'application/json',
								'x-site-domain': origin,
							},
							body: JSON.stringify({ intervalTag: intervalTag })
						})
						.then(response => {
							if (!response.ok) {
								throw new Error('Network response was not ok');
							}
							status.textContent = '<?php _e( 'Update successful!', 'woocommerce-search' ); ?>';
							status.style.color = 'green';
						})
						.catch(error => {
							console.error('Error:', error);
							status.textContent = '<?php _e( 'Update failed. Please try again.', 'woocommerce-search' ); ?>';
							status.style.color = 'red';
						})
						.finally(() => {
							button.disabled = false;
						});
					});

					// Confirm Project Key
					document.getElementById('confirm-key-button').addEventListener('click', function() {
						const button = this;
						const status = document.getElementById('confirm-key-status');
						const keyInput = document.getElementById('project-key');
						const key = keyInput.value.trim();
						
						if (!key) {
							alert('<?php _e( 'Please enter a key', 'woocommerce-search' ); ?>');
							return;
						}

						button.disabled = true;
						status.textContent = '<?php _e( 'Submitting...', 'woocommerce-search' ); ?>';
						status.style.color = 'inherit';

						fetch(ENDPOINT + "/api/project/" + encodeURIComponent(key) + "/domain", {
							method: 'PUT',
							headers: {
								'Content-Type': 'application/json',
								'x-site-domain': origin,
							}
						})
						.then(response => {
							if (!response.ok) {
								throw new Error('Network response was not ok');
							}
							window.location.reload();
						})
						.catch(error => {
							console.error('Error:', error);
							status.textContent = '<?php _e( 'Update failed. Please try again.', 'woocommerce-search' ); ?>';
							status.style.color = 'red';
						})
						.finally(() => {
							button.disabled = false;
						});
					});
				})();
			</script>
		</div>
		<?php
	}

	/**
	 * Initialize the plugin
	 */
	public function init() {
		// Initialization logic here
	}
}

/**
 * Function for delaying initialization of the extension until after WooCommerce is loaded.
 */
function wc_advanced_search_initialize() {

    // This is also a great place to check for the existence of the WooCommerce class
    if ( ! class_exists( 'WooCommerce' ) ) {
    // You can handle this situation in a variety of ways,
    //   but adding a WordPress admin notice is often a good tactic.
        return;
    }

    $GLOBALS['wc_advanced_search'] = WC_Advanced_Search::instance();
}

add_action( 'plugins_loaded', 'wc_advanced_search_initialize', 10 );
