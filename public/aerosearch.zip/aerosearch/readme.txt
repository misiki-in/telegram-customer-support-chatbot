=== AeroSearch ===
Contributors: Swadesh Behera
Tags: woocommerce, search
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.0.0
License: GPL-3.0
License URI: https://www.gnu.org/licenses/gpl-3.0.html

All you need with a WooCommerce search extension.

== Description ==

AeroSearch transforms your WooCommerce store with fast, intelligent search capabilities. The plugin connects to the Aerosearch Search API to provide:

* **Millisecond Search Results** - Give your customers instant search results they expect
* **Product Syncing** - Automatically sync your WooCommerce products to the search index
* **Intelligent Filtering** - Help customers find products with faceted search filters
* **Admin Dashboard** - Manage your search settings, monitor sync status, and configure project options
* **Mobile Optimized** - Delivers fast search experience across all devices

== External Services ==

This plugin relies on an external third-party service to provide search functionality.

**AeroSearch API**

1. **What the service is and what it is used for**
   The AeroSearch API provides fast, intelligent search capabilities for WooCommerce stores. It is used for product syncing to a search index, delivering millisecond-fast search results, and managing project settings.

2. **What data is sent and when**
   The following data is sent to the AeroSearch Cloud API:
   - **Site domain**: Sent on plugin activation, deactivation, and with every API request to identify your store
   - **Project key**: Sent when you enter and confirm your project key in the dashboard to associate your domain with a project
   - **Sync interval settings**: Sent when you update sync preferences in the admin dashboard
   - **Sync trigger request**: Sent when you manually trigger a product sync from the dashboard

3. **Terms of Service and Privacy Policy**
   - Terms of Service: https://aerosearch.cloud/terms
   - Privacy Policy: https://aerosearch.cloud/privacy

== Installation ==

1. Install and activate the plugin on your WordPress site
2. Get a project key from https://aerosearch.cloud
3. Enter the key in the AeroSearch dashboard to connect your domain with a project
4. Trigger the initial products sync

The plugin works as a frontend interface to the Aerosearch Search API, which handling product synchronization, search queries, and providing an easy-to-use admin interface for managing your search configuration.
