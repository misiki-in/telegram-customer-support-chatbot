<?php
/**
 * Plugin Name: AeroSearch
 * Plugin URI:  https://aerosearch.cloud
 * Description: All you need with a WooCommerce search extension.
 * Version:     1.0.0
 * Contributors: Swadesh Behera
 * Author:      Swadesh Behera
 * Author URI:  https://github.com/itswadesh
 * License:     GPL-3.0
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain: aerosearch
 *
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'AEROSEARCH_SEARCH_ENDPOINT', 'https://api.wooquery.com' );
define( 'AEROSEARCH_VERSION', '1.0.0' );

/**
 * Activation hook
 */
function aerosearch_activate() {
	$domain = home_url();
	$response = wp_remote_post(
		esc_url_raw( AEROSEARCH_SEARCH_ENDPOINT . '/api/store/activate' ),
		array(
			'headers' => array(
				'x-site-domain' => esc_url_raw( $domain ),
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		error_log( 'AeroSearch activation request failed: ' . $response->get_error_message() );
	}
}

/**
 * Deactivation hook
 */
function aerosearch_deactivate() {
	$domain = home_url();
	$response = wp_remote_request(
		esc_url_raw( AEROSEARCH_SEARCH_ENDPOINT . '/api/store/deactivate' ),
		array(
			'method'  => 'DELETE',
			'headers' => array(
				'x-site-domain' => esc_url_raw( $domain ),
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		error_log( 'AeroSearch deactivation request failed: ' . $response->get_error_message() );
	}
}

register_activation_hook( __FILE__, 'aerosearch_activate' );
register_deactivation_hook( __FILE__, 'aerosearch_deactivate' );

/**
 * Main AeroSearch Class
 */
class Aerosearch_Search {

	/**
	 * Instance of this class.
	 *
	 * @var Aerosearch_Search
	 */
	private static $_instance = null;

	/**
	 * Get the instance of this class.
	 *
	 * @return Aerosearch_Search
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Prevent cloning the instance.
	 */
	private function __clone() {}

	/**
	 * Prevent unserializing the instance.
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin huh?', 'aerosearch' ), '1.0.0' );
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_storefront_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}

	/**
	 * Enqueue Storefront Scripts
	 */
	public function enqueue_storefront_scripts() {
		if ( is_admin() ) {
			return;
		}

		wp_enqueue_script(
			'aerosearch-main',
			esc_url( plugins_url( 'assets/js/main.js', __FILE__ ) ),
			array(),
			AEROSEARCH_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
	}

	/**
	 * Enqueue Admin Scripts
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( 'toplevel_page_aerosearch-dashboard' !== $hook ) {
			return;
		}

		wp_enqueue_script(
			'aerosearch-dashboard',
			esc_url( plugins_url( 'assets/js/dashboard.js', __FILE__ ) ),
			array(),
			AEROSEARCH_VERSION,
			true
		);

		wp_localize_script(
			'aerosearch-dashboard',
			'aerosearch_data',
			array(
				'endpoint' => esc_url_raw( AEROSEARCH_SEARCH_ENDPOINT ),
				'i18n'     => array(
					'never'         => esc_html__( 'Never', 'aerosearch' ),
					'na'            => esc_html__( 'N/A', 'aerosearch' ),
					'syncing'       => esc_html__( 'Syncing...', 'aerosearch' ),
					'syncSuccess'   => esc_html__( 'Sync successful!', 'aerosearch' ),
					'syncFailed'    => esc_html__( 'Sync failed. Please try again.', 'aerosearch' ),
					'updating'      => esc_html__( 'Updating...', 'aerosearch' ),
					'updateSuccess' => esc_html__( 'Update successful!', 'aerosearch' ),
					'updateFailed'  => esc_html__( 'Update failed. Please try again.', 'aerosearch' ),
					'enterKey'      => esc_html__( 'Please enter a key', 'aerosearch' ),
					'submitting'    => esc_html__( 'Submitting...', 'aerosearch' ),
				),
			)
		);
	}

	/**
	 * Add Admin Menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			esc_html__( 'AeroSearch', 'aerosearch' ),
			esc_html__( 'AeroSearch', 'aerosearch' ),
			'manage_options',
			'aerosearch-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-search',
			56
		);
	}

	/**
	 * Render Dashboard Page
	 */
	public function render_dashboard() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'AeroSearch Dashboard', 'aerosearch' ); ?></h1>
			<p><?php esc_html_e( 'Manage your search settings and sync products.', 'aerosearch' ); ?></p>
			<p style="background-color: yellow; padding: 10px; font-weight: bold;"><?php esc_html_e( 'This plugin requires a ecommerce theme with a search bar.', 'aerosearch' ); ?></p>
			
			<hr />

			<div id="aerosearch-external-sync-message" style="display: none; margin-top: 20px; padding: 10px; background: #fff; border-left: 4px solid #ffba00; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
				<strong><?php esc_html_e( 'Sync is managed externally', 'aerosearch' ); ?></strong>
			</div>

			<div id="aerosearch-project-not-associated" style="display: none; margin-top: 20px; padding: 20px; background: #fff; border-left: 4px solid #dc3232; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
				<div style="margin-top: 15px;">
					<label for="aerosearch-project-key" style="display: block; margin-bottom: 5px;"><strong><?php esc_html_e( 'Key', 'aerosearch' ); ?></strong></label>
					<p style="margin-top: 15px;">
						<?php
						printf(
							/* translators: %s: link to dashboard */
							esc_html__( 'Get the key %s.', 'aerosearch' ),
							sprintf(
								'<a href="%1$s" target="_blank">%2$s</a>',
								esc_url( 'https://aerosearch.cloud/dash' ),
								esc_html__( 'here', 'aerosearch' )
							)
						);
						?>
					</p>
					<input type="text" id="aerosearch-project-key" style="width: 300px; margin-bottom: 10px;" />
					<br />
					<button id="aerosearch-confirm-key-button" class="button button-primary">
						<?php esc_html_e( 'Confirm Key', 'aerosearch' ); ?>
					</button>
					<span id="aerosearch-confirm-key-status" style="margin-left: 10px;"></span>
					<p style="margin-top: 15px;">
						<?php
						printf(
							/* translators: %s: link to guide */
							esc_html__( 'Get a step by step interactive guide on how to setup %s.', 'aerosearch' ),
							sprintf(
								'<a href="%1$s" target="_blank">%2$s</a>',
								esc_url( 'https://aerosearch.cloud/guide' ),
								esc_html__( 'here', 'aerosearch' )
							)
						);
						?>
					</p>
				</div>
			</div>

			<div id="aerosearch-dashboard-controls" style="display: none;">
				<div class="aerosearch-project-settings-section" style="margin-top: 20px; padding: 20px; background: #fff; border-left: 4px solid #0073aa; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
					<h3 style="margin-top: 0;"><?php esc_html_e( 'Project settings', 'aerosearch' ); ?></h3>
					<p><strong><?php esc_html_e( 'Project Name', 'aerosearch' ); ?>:</strong> <span id="aerosearch-project-name"></span></p>
					<button id="aerosearch-change-key-button" class="button button-secondary">
						<?php esc_html_e( 'Change Key', 'aerosearch' ); ?>
					</button>
				</div>

				<div class="aerosearch-sync-settings-section" style="margin-top: 20px; padding: 20px; background: #fff; border-left: 4px solid #46b450; box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
					<h3 style="margin-top: 0;"><?php esc_html_e( 'Sync Settings', 'aerosearch' ); ?></h3>
					<p><strong><?php esc_html_e( 'Last Synced At', 'aerosearch' ); ?>:</strong> <span id="aerosearch-last-synced-at"></span></p>

					<div id="aerosearch-sync-interval-section" class="aerosearch-sync-interval-section" style="margin-top: 20px;">
						<label for="aerosearch-sync-interval-dropdown"><strong><?php esc_html_e( 'Sync interval', 'aerosearch' ); ?>:</strong> </label>
						<select id="aerosearch-sync-interval-dropdown" style="min-width: 150px;"></select>
						<button id="aerosearch-update-sync-interval-button" class="button button-secondary">
							<?php esc_html_e( 'Update Sync Interval', 'aerosearch' ); ?>
						</button>
						<span id="aerosearch-update-interval-status" style="margin-left: 10px;"></span>
					</div>

					<div class="aerosearch-sync-section" style="margin-top: 20px; border-top: 1px solid #ddd; padding-top: 20px;">
						<button id="aerosearch-sync-products-button" class="button button-primary">
							<?php esc_html_e( 'Trigger Products Sync', 'aerosearch' ); ?>
						</button>
						<span id="aerosearch-sync-status" style="margin-left: 10px;"></span>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Initialize the plugin
	 */
	public function init() {
		// Initialization logic here
	}
}

/**
 * Function for delaying initialization of the extension until after WooCommerce is loaded.
 */
function aerosearch_initialize() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	$GLOBALS['aerosearch_instance'] = Aerosearch_Search::instance();
}

add_action( 'plugins_loaded', 'aerosearch_initialize', 10 );
